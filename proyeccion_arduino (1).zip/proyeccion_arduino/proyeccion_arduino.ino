/*
  Espejo Hiladoras · lector de tags para Arduino UNO + RC522
  Manda por USB (serial 9600) una línea cuando cambia el accesorio:
    CHIP-COLLAR | CHIP-BOLSO | CHIP-PULSERA   → hay un accesorio en la mesa
    RETIRAR                                   → se retiró
  Cableado RC522 → UNO:  SDA 10 · SCK 13 · MOSI 11 · MISO 12 · RST 9 · 3.3V · GND   (¡3.3V, no 5V!)
  Librería necesaria: MFRC522 (Gestor de librerías)
*/
#include <SPI.h>
#include <MFRC522.h>

MFRC522 rfid(10, 9);

// ← CAMBIA ESTOS UID por los de tus tags (mira el Monitor Serie con MODO_PRUEBA = true)
// Pega el UID completo tal como sale en el Monitor Serie: sirve con 4 bytes o con 7 (tags NTAG).
const byte UID_COLLAR[]  = {0x4, 0xFD, 0xCD, 0x4C, 0xB9, 0x2A, 0x81};
const byte UID_BOLSO[]   = {0x4, 0x11, 0xCE, 0x4C, 0xB9, 0x2A, 0x81};
const byte UID_PULSERA[] = {0x4, 0x19, 0xCE, 0x4C, 0xB9, 0x2A, 0x81};

const bool MODO_PRUEBA = false;            // true: imprime el UID de cada tag que acerques. Ponlo en false al terminar.
const unsigned long RETIRO_MS = 600;      // ms sin ver el tag para considerarlo retirado

const char *actual = nullptr;
unsigned long ultimaVez = 0;

bool igual(const byte *ref, byte n) {
  if (rfid.uid.size != n) return false;
  for (byte i = 0; i < n; i++) if (rfid.uid.uidByte[i] != ref[i]) return false;
  return true;
}

void setup() {
  Serial.begin(9600);
  SPI.begin();
  rfid.PCD_Init();
  byte v = rfid.PCD_ReadRegister(MFRC522::VersionReg);
  Serial.print("Version del lector: 0x"); Serial.println(v, HEX);   // 0x91, 0x92, 0x88 o 0x12 = bien. 0x00 o 0xFF = sin comunicacion (cableado)
  if (MODO_PRUEBA) Serial.println("Modo prueba: acerca un tag...");
}

void loop() {
  byte atqa[2]; byte len = sizeof(atqa);
  // En modo prueba se usa la lectura estandar; en modo normal se "despierta" el tag para saber si sigue en la mesa
  bool hayTag = MODO_PRUEBA ? (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial())
                            : (rfid.PICC_WakeupA(atqa, &len) == MFRC522::STATUS_OK && rfid.PICC_ReadCardSerial());
  if (hayTag) {
    if (MODO_PRUEBA) {
      Serial.print("UID: ");
      for (byte i = 0; i < rfid.uid.size; i++) { Serial.print("0x"); Serial.print(rfid.uid.uidByte[i], HEX); Serial.print(' '); }
      Serial.println();
    } else {
      const char *chip = nullptr;
      if (igual(UID_COLLAR, sizeof(UID_COLLAR)))       chip = "CHIP-COLLAR";
      else if (igual(UID_BOLSO, sizeof(UID_BOLSO)))   chip = "CHIP-BOLSO";
      else if (igual(UID_PULSERA, sizeof(UID_PULSERA))) chip = "CHIP-PULSERA";
      if (chip) {
        ultimaVez = millis();
        if (chip != actual) { Serial.println(chip); actual = chip; }
      }
    }
    rfid.PICC_HaltA();
    rfid.PCD_StopCrypto1();
  }

  if (!MODO_PRUEBA && actual && millis() - ultimaVez > RETIRO_MS) {
    Serial.println("RETIRAR");
    actual = nullptr;
  }
  delay(50);
}
